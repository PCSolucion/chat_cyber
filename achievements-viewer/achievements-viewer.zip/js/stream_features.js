/**
 * Stream Features Module
 * Handles Stream Activity Heatmap and Stream Stats for Netrunner Data
 */
const StreamFeatures = (function () {
    'use strict';

    // State
    const _streamData = {
        history: {},
        stats: {
            longestStream: { duration: 0, date: null, title: '' },
            mostFrequentCategory: { name: '', count: 0 },
            totalStreams: 0,
            totalDuration: 0
        }
    };
    let _activeYear = new Date().getFullYear();

    // Raw Data (Parsed from user input)
    const RAW_STREAM_DATA = {
        "2026-01-28": { duration: 347, category: "Night of the Dead", title: "NOTD Directo #81 y luego Cyberpunk 2077 | Live #20 | FINAL HISTORIA PRINCIPAL" },
        "2026-01-27": { duration: 104, category: "Cyberpunk 2077", title: "Cyberpunk 2077 | Live #19 | FINAL HISTORIA PRINCIPAL" },
        "2026-01-26": { duration: 237, category: "Cyberpunk 2077", title: "Cyberpunk 2077 | Live #18" },
        "2026-01-25": { duration: 472, category: "New World: Aeternum", title: "NW Aeternum | Directo #971 | MALAS NOTICIAS... Britney Spears vuelve a los escenarios este 2026" },
        "2026-01-24": { duration: 776, category: "Night of the Dead", title: "NOTD #79" },
        "2026-01-23": { duration: 396, category: "Cyberpunk 2077", title: "Cyberpunk 2077 | Live #17" },
        "2026-01-22": { duration: 246, category: "Cyberpunk 2077", title: "Cyberpunk 2077 | Live #16" },
        "2026-01-21": { duration: 267, category: "Night of the Dead", title: "NOTD #78 y luego Cyberpunk 2077 | Live #16" },
        "2026-01-20": { duration: 261, category: "Cyberpunk 2077", title: "Cyberpunk 2077 | Live #15" },
        "2026-01-19": { duration: 266, category: "Cyberpunk 2077", title: "Cyberpunk 2077 | Live #14 | Hoy un buen PUSH a las misiones principales" },
        "2026-01-18": { duration: 576, category: "Night of the Dead", title: "NOTD #77 y a las 21:00 New World Aeternum | Directo #969" },
        "2026-01-17": { duration: 397, category: "New World: Aeternum", title: "New World Aeternum | Directo #967 | NO CIERRA YA, QUEDA MÁS DE UN AÑO 🤦" },
        "2026-01-16": { duration: 407, category: "Cyberpunk 2077", title: "Cyberpunk 2077 | Live #13" },
        "2026-01-15": { duration: 309, category: "Cyberpunk 2077", title: "Cyberpunk 2077 Live #12 | A las 23:00 evento CAPCOM de Resident Evil Re9uiem | NW cierra servers el 31 de Enero 2027" },
        "2026-01-14": { duration: 306, category: "Night of the Dead", title: "NOTD Directo #76 y luego Cyberpunk 2077 | Directo #12" },
        "2026-01-13": { duration: 283, category: "Cyberpunk 2077", title: "Cyberpunk 2077 | Directo #11 | Noob juegando en Máxima Dificultad | ☠️ Contador de muertes ☠️" },
        "2026-01-12": { duration: 259, category: "Cyberpunk 2077", title: "Cyberpunk 2077 | Directo #10 | Noob juegando en Máxima Dificultad | ☠️ Contador de muertes ☠️" },
        "2026-01-11": { duration: 569, category: "New World: Aeternum", title: "New World Aeternum #967 y luego Night of the Dead #75" },
        "2026-01-10": { duration: 726, category: "Cyberpunk 2077", title: "Cyberpunk 2077 | Directo #8" },
        "2026-01-09": { duration: 592, category: "Cyberpunk 2077", title: "Cyberpunk 2077 | Directo 5 | Probando DLSS 4.5" },
        "2026-01-08": { duration: 396, category: "New World: Aeternum", title: "New World Aeternum | Directo #964" },
        "2026-01-07": { duration: 166, category: "New World: Aeternum", title: "New World Aeternum | Directo #963" },
        "2026-01-06": { duration: 227, category: "Night of the Dead", title: "Night of the Dead | Directo #74" },
        "2026-01-05": { duration: 180, category: "Night of the Dead", title: "Night of the Dead | Directo #72 | Construyendo el Bernabeu" },
        "2026-01-04": { duration: 135, category: "Night of the Dead", title: "Night of the Dead Directo #71" },
        "2026-01-03": { duration: 534, category: "New World: Aeternum", title: "New World Directo #961 y luego Cyberpunk 2077 Directo #3" },
        "2026-01-02": { duration: 346, category: "New World: Aeternum", title: "New World Directo #960 y luego Cyberpunk 2077 Directo #2" },
        "2026-01-01": { duration: 272, category: "Cyberpunk 2077", title: "Cyberpunk 2077 | Directo #1 | Mañana NW y usa !vote para elegir el siguiente juego" },

        "2025-12-31": { duration: 184, category: "New World: Aeternum", title: "New World Directo #959 y luego Night of the Dead Directo #70" },
        "2025-12-30": { duration: 567, category: "New World: Aeternum", title: "New World Directo #958 y luego Night of the Dead Directo #69" },
        "2025-12-29": { duration: 325, category: "Night of the Dead", title: "Night of the Dead Directo #68" },
        "2025-12-28": { duration: 604, category: "New World: Aeternum", title: "New World Directo #956 y luego Night of the Dead Directo #66" },
        "2025-12-27": { duration: 405, category: "New World: Aeternum", title: "New World Directo #955 y luego Night of the Dead Directo #64" },
        "2025-12-26": { duration: 660, category: "New World: Aeternum", title: "New World Directo #954 y luego Night of the Dead Directo #63" },
        "2025-12-25": { duration: 379, category: "New World: Aeternum", title: "New World Directo #952 y luego Night of the Dead Directo #62" },
        "2025-12-24": { duration: 584, category: "Night of the Dead", title: "Night of the Dead Directo #60 y luego New World Directo #951" },
        "2025-12-23": { duration: 791, category: "Night of the Dead", title: "Night of the Dead | Directo #59 | Powered by Radio Ukraina" },
        "2025-12-22": { duration: 732, category: "Night of the Dead", title: "Night of the Dead Directo #56 y después Euro Truck Simulator 2 Directo #5" },
        "2025-12-21": { duration: 632, category: "Night of the Dead", title: "Night of the Dead Directo #54 y luego New World Directo #948" },
        "2025-12-20": { duration: 469, category: "New World: Aeternum", title: "New World Directo #945" },
        "2025-12-19": { duration: 335, category: "New World: Aeternum", title: "New World Directo #943 y luego Euro Truck Simulator 2 Directo #2 de Salamanca a Sevilla" },
        "2025-12-18": { duration: 182, category: "New World: Aeternum", title: "New World Directo #942 y luego pruebo Euro Truck Simulator con mods de Coruña y Santiago" },
        "2025-12-16": { duration: 477, category: "New World: Aeternum", title: "New World Aeternum (pero no mucho) Directo #941" },
        "2025-12-15": { duration: 465, category: "New World: Aeternum", title: "New World Aeternum Directo #939 y depués ya veremos" },
        "2025-12-14": { duration: 275, category: "New World: Aeternum", title: "New World Aeternum Directo #937" },
        "2025-12-12": { duration: 186, category: "New World: Aeternum", title: "New World Directo #936 y luego KCD2 Directo #10" },
        "2025-12-11": { duration: 522, category: "New World: Aeternum", title: "New World Directo #935 y luego los GOTY 2025 a las 01:00 AM" },
        "2025-12-10": { duration: 481, category: "New World: Aeternum", title: "New World Directo #933" },
        "2025-12-09": { duration: 363, category: "New World: Aeternum", title: "New World Aeternum Directo #931" },
        "2025-12-08": { duration: 490, category: "New World: Aeternum", title: "New World Aeternum Directo #930" },
        "2025-12-07": { duration: 450, category: "New World: Aeternum", title: "NW Directo #928 luego SOULFRAME RPG Online Cooperativo | Directo #2 | DROPS KEY 30 minutos" },
        "2025-12-06": { duration: 626, category: "New World: Aeternum", title: "NW Directo #927 luego SOULFRAME RPG Online Cooperativo | Directo #2 | DROPS KEY 30 minutos" },
        "2025-12-05": { duration: 630, category: "Soulframe", title: "SOULFRAME | Directo #1" },
        "2025-12-04": { duration: 295, category: "New World: Aeternum", title: "New World Aeternum | Directo #924" },
        "2025-12-03": { duration: 283, category: "New World: Aeternum", title: "New World Aeternum | Directo #923" },
        "2025-11-30": { duration: 547, category: "New World: Aeternum", title: "New World Aeternum | Directo #922" }
    };

    /**
     * Initialize Stream Data
     */
    async function initData() {
        _streamData.history = RAW_STREAM_DATA;
        calculateStats();
        return _streamData;
    }

    /**
     * Calculate Stats from History
     */
    function calculateStats() {
        let longest = { duration: 0, date: null, title: '' };
        let totalDuration = 0;
        let totalStreams = 0;
        const catCounts = {};

        Object.entries(_streamData.history).forEach(([date, day]) => {
            totalStreams++;
            totalDuration += day.duration;

            if (day.duration > longest.duration) {
                longest = { ...day, date: date };
            }

            if (day.category) {
                catCounts[day.category] = (catCounts[day.category] || 0) + 1;
            }
        });

        // Find most frequent category
        let mostFrequent = { name: '', count: 0 };
        Object.entries(catCounts).forEach(([name, count]) => {
            if (count > mostFrequent.count) {
                mostFrequent = { name, count };
            }
        });

        _streamData.stats = {
            longestStream: longest,
            mostFrequentCategory: mostFrequent,
            totalStreams,
            totalDuration
        };
    }

    /**
     * Get available years from history
     */
    function getAvailableYears() {
        const years = new Set();
        years.add(new Date().getFullYear());

        Object.keys(_streamData.history).forEach(date => {
            const y = parseInt(date.split('-')[0]);
            if (!isNaN(y)) years.add(y);
        });

        return Array.from(years).sort((a, b) => b - a);
    }

    /**
     * Generate HTML for the heatmap grid
     */
    function generateHeatmapGrid(year) {
        year = year || new Date().getFullYear();

        // Use logic similar to ProfileFeatures but adapted
        const jan1 = new Date(year, 0, 1);
        const dayOfWeek = jan1.getDay(); // 0 = Sunday
        const startDate = new Date(year, 0, 1 - dayOfWeek);
        const weeks = 53;

        let cellsHTML = '';
        const months = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
        const monthLabels = [];
        let currentMonth = -1;

        for (let w = 0; w < weeks; w++) {
            let weekHTML = `<div class="heatmap-column" data-week="${w}">`;

            for (let d = 0; d < 7; d++) {
                const currentDate = new Date(startDate);
                currentDate.setDate(startDate.getDate() + (w * 7) + d);

                const y = currentDate.getFullYear();
                const m = String(currentDate.getMonth() + 1).padStart(2, '0');
                const dd = String(currentDate.getDate()).padStart(2, '0');
                const dateKey = `${y}-${m}-${dd}`;

                // Track month changes for labels
                if (currentDate.getMonth() !== currentMonth && y === year) {
                    currentMonth = currentDate.getMonth();
                    monthLabels.push({ month: months[currentMonth], weekIndex: w });
                }

                const dayData = _streamData.history[dateKey];
                const isRequestedYear = (y === year);
                const isFuture = currentDate > new Date();

                let level = 0;
                let tooltipData = '';

                if (dayData && isRequestedYear) {
                    // Determine intensity based on duration (1-4)
                    if (dayData.duration > 360) level = 4; // > 6h
                    else if (dayData.duration > 240) level = 3; // > 4h
                    else if (dayData.duration > 120) level = 2; // > 2h
                    else level = 1;

                    tooltipData = `
                        data-date="${dateKey}"
                        data-title="${Utils.escapeHTML(dayData.title)}"
                        data-duration="${dayData.duration}"
                        data-category="${Utils.escapeHTML(dayData.category)}"
                    `;
                }

                const dimClass = !isRequestedYear ? 'dimmed' : '';
                const futureClass = isFuture ? 'future' : '';

                weekHTML += `
                    <div class="heatmap-cell level-${level} ${dimClass} ${futureClass} stream-cell" 
                         ${tooltipData}
                         data-level="${level}"
                         style="${!isRequestedYear ? 'opactiy:0.1; visibility:hidden;' : ''}"
                    ></div>
                `;
            }
            weekHTML += '</div>';
            cellsHTML += weekHTML;
        }

        return { html: cellsHTML, labels: monthLabels };
    }

    /**
     * Create Stream Heatmap Component
     */
    async function createStreamHeatmap() {
        if (Object.keys(_streamData.history).length === 0) {
            await initData();
        }

        const years = getAvailableYears();
        const gridData = generateHeatmapGrid(_activeYear);

        // Stats for the header
        const stats = _streamData.stats;

        // Tabs HTML
        const tabsHTML = years.map(y => `
            <button class="heatmap-tab ${y === _activeYear ? 'active' : ''}" 
                    onclick="StreamFeatures.switchYear(${y})">
                ${y}
            </button>
        `).join('');

        const days = ['Dom', '', 'Mar', '', 'Jue', '', 'Sáb'];

        return `
            <div class="stream-stats-dashboard">
                <!-- Highlight Stats -->
                <div class="stream-highlights">
                    <div class="stream-stat-card">
                        <div class="stat-icon">⏱️</div>
                        <div class="stat-info">
                            <span class="label">STREAM MÁS LARGO</span>
                            <span class="value">${Utils.formatTime(stats.longestStream.duration)}</span>
                            <span class="sub" title="${Utils.escapeHTML(stats.longestStream.title)}">${Utils.escapeHTML(stats.longestStream.date || 'N/A')}</span>
                        </div>
                    </div>
                    <div class="stream-stat-card">
                        <div class="stat-icon">📺</div>
                        <div class="stat-info">
                            <span class="label">CAT. FAVORITA</span>
                            <span class="value">${stats.mostFrequentCategory.name}</span>
                            <span class="sub">${stats.mostFrequentCategory.count} streams</span>
                        </div>
                    </div>
                    <div class="stream-stat-card">
                        <div class="stat-icon">📊</div>
                        <div class="stat-info">
                            <span class="label">TOTAL STREAMS</span>
                            <span class="value">${stats.totalStreams}</span>
                            <span class="sub">${Utils.formatTime(stats.totalDuration)} totales</span>
                        </div>
                    </div>
                </div>

                <!-- Heatmap Section -->
                <div class="profile-advanced-section stream-heatmap-section">
                     <div class="section-header-row" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem;">
                        <div>
                            <h3 class="advanced-section-title">Calendario de Transmisiones</h3>
                            <p class="advanced-section-subtitle">Frecuencia y duración de streams durante el año</p>
                        </div>
                        <div class="heatmap-tabs">
                            ${tabsHTML}
                        </div>
                    </div>

                    <div id="stream-heatmap-container-dynamic" class="activity-heatmap-container">
                        <div class="heatmap-months">
                            ${gridData.labels.map(m => `<span class="heatmap-month-label" style="left: ${m.weekIndex * 12}px">${m.month}</span>`).join('')}
                        </div>
                        <div class="heatmap-wrapper">
                            <div class="heatmap-days">
                                ${days.map(d => `<span class="heatmap-day-label">${d}</span>`).join('')}
                            </div>
                            <div class="activity-heatmap" id="stream-heatmap-grid">
                                ${gridData.html}
                            </div>
                        </div>
                    </div>

                    <div class="heatmap-legend">
                        <span>Menos Duración</span>
                        <div class="legend-scale">
                             <div class="legend-cell heatmap-cell" data-level="1"></div>
                             <div class="legend-cell heatmap-cell" data-level="2"></div>
                             <div class="legend-cell heatmap-cell" data-level="3"></div>
                             <div class="legend-cell heatmap-cell" data-level="4"></div>
                        </div>
                        <span>Más Duración</span>
                    </div>
                </div>
            </div>
        `;
    }

    /**
     * Switch Year
     */
    function switchYear(year) {
        _activeYear = year;
        const gridData = generateHeatmapGrid(year);

        // Update Grid
        const gridContainer = document.getElementById('stream-heatmap-grid');
        if (gridContainer) {
            gridContainer.innerHTML = gridData.html;
        }

        // Update Tabs
        document.querySelectorAll('.stream-heatmap-section .heatmap-tab').forEach(btn => {
            btn.classList.toggle('active', parseInt(btn.innerText) === year);
        });

        setupTooltips();
    }

    /**
     * Setup Tooltips
     */
    function setupTooltips() {
        const cells = document.querySelectorAll('.stream-cell:not(.future)');
        let tooltip = document.getElementById('stream-tooltip');

        if (!tooltip) {
            tooltip = document.createElement('div');
            tooltip.id = 'stream-tooltip';
            tooltip.className = 'heatmap-tooltip';
            document.body.appendChild(tooltip);
        }

        cells.forEach(cell => {
            cell.addEventListener('mouseenter', () => {
                const date = cell.dataset.date;
                if (!date || !cell.dataset.title) return; // Empty cell

                const title = cell.dataset.title;
                const duration = parseInt(cell.dataset.duration);
                const category = cell.dataset.category;

                const formattedDate = new Date(date).toLocaleDateString('es-ES', {
                    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
                });

                tooltip.innerHTML = `
                    <div class="stream-tooltip-content">
                        <div class="date">${formattedDate}</div>
                        <div class="stream-title">${title}</div>
                        <div class="stream-meta">
                            <span class="duration">⏱️ ${Utils.formatTime(duration)}</span>
                            <span class="category">📺 ${category}</span>
                        </div>
                    </div>
                `;

                tooltip.style.display = 'block';

                const rect = cell.getBoundingClientRect();
                tooltip.style.left = `${rect.left + rect.width / 2}px`;
                tooltip.style.top = `${rect.top - tooltip.offsetHeight - 10}px`;
                tooltip.style.transform = 'translateX(-50%)';
            });

            cell.addEventListener('mouseleave', () => {
                tooltip.style.display = 'none';
            });
        });
    }

    return {
        createStreamHeatmap,
        switchYear,
        setupTooltips
    };

})();
